package firstwebapp.resources;

import com.google.cloud.Timestamp;
import com.google.cloud.datastore.*;
import com.google.gson.Gson;
import firstwebapp.util.*;
import org.apache.commons.codec.digest.DigestUtils;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

@Path("/ti")
public class RegisterResource {

    private final Datastore datastore = DatastoreOptions.getDefaultInstance().getService();
    private final Gson g = new Gson();


    @POST
    @Path("/register")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response register(RegistrationData data){
        if(!data.validRegistration()) {
            return Response.status(Response.Status.BAD_REQUEST).entity("Missing or wrong parameter.").build();
        }
        Transaction txn = datastore.newTransaction();

        try{
            Key userKey = datastore.newKeyFactory().setKind("User").newKey(data.username);
            Entity user = datastore.get(userKey);

            if(user != null){
                txn.rollback();
                return Response.status(Response.Status.CONFLICT).entity("User already exists.").build();
            }
            else {
                Entity.Builder builder = Entity.newBuilder(userKey);

                builder.set("user_username", data.username)
                        .set("user_email", data.email)
                        .set("user_name", data.name)
                        .set("user_pwd", DigestUtils.sha512Hex(data.password));

                builder = data.profile != null ? builder.set("user_profile", data.profile) : builder.set("user_profile", "INDEFINIDO");
                builder = data.phone != null ? builder.set("user_phone", data.phone) : builder.set("user_phone", "INDEFINIDO");
                builder = data.cellphone != null ? builder.set("user_cellphone", data.cellphone) : builder.set("user_cellphone", "INDEFINIDO");
                builder = data.address != null ? builder.set("user_address", data.address) : builder.set("user_address", "INDEFINIDO");
                builder = data.addressC != null ? builder.set("user_addressC", data.addressC) : builder.set("user_addressC", "INDEFINIDO");
                builder = data.localidade != null ? builder.set("user_localidade", data.localidade) : builder.set("user_localidade", "INDEFINIDO");
                builder = data.cp != null ? builder.set("user_cp", data.cp) : builder.set("user_cp", "INDEFINIDO");
                builder = data.nif != null ? builder.set("user_nif", data.nif) : builder.set("user_nif", "INDEFINIDO");

                user = builder.set("user_creation_time", Timestamp.now())
                        .set("user_role", "USER")
                        .set("user_state", "INACTIVE")
                        .build();
            }

            //txn.add(user);
            txn.rollback();

            return Response.ok("User created successfully").build();
        }
        finally {
            if(txn.isActive()){
                txn.rollback();
            }
        }

    }


    @POST
    @Path("/listUsers")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response listUsers(ListUsersData data) {
        Key userKey = datastore.newKeyFactory().setKind("User").newKey(data.username);
        Entity user = datastore.get(userKey);

        if (user == null) {
            return Response.status(Response.Status.CONFLICT).entity("User does not exist.").build();
        }

        if (!data.verifier.equals("secret")) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong verifier.").build();
        }

        if (data.validTo < System.currentTimeMillis()) {
            return Response.status(Response.Status.FORBIDDEN).entity("Token expired.").build();
        }


        Query<Entity> query;
        Entity listElement;
        List<Entity> usersList = new LinkedList<>();

        if(data.role.equals("USER")) {
            query = Query.newEntityQueryBuilder()
                    .setKind("User")
                    .setFilter(StructuredQuery.PropertyFilter.eq("user_role", "USER"))
                    .setFilter(StructuredQuery.PropertyFilter.eq("user_profile", "PÚBLICO"))
                    .setFilter(StructuredQuery.PropertyFilter.eq("user_state", "ATIVO"))
                    .build();

            QueryResults<Entity> queryResults = datastore.run(query);

            //TODO: so passar username, email e nome
            while(queryResults.hasNext()){
                listElement = queryResults.next();
                usersList.add(listElement);
            }
        }

        if(data.role.equals("GBO")) {
            query = Query.newEntityQueryBuilder()
                    .setKind("User")
                    .setFilter(StructuredQuery.PropertyFilter.eq("user_role", "USER"))
                    .build();

            QueryResults<Entity> queryResults = datastore.run(query);

            //TODO: lista todos os atributos
            while(queryResults.hasNext()){
                listElement = queryResults.next();
                usersList.add(listElement);
            }
        }

        if(data.role.equals("GBS")) {
            query = Query.newEntityQueryBuilder()
                    .setKind("User")
                    .setFilter(StructuredQuery.PropertyFilter.eq("user_role", "USER"))
                    .setFilter(StructuredQuery.PropertyFilter.eq("user_role", "GBO"))
                    .build();

            QueryResults<Entity> queryResults = datastore.run(query);

            //TODO: lista todos os atributos
            while(queryResults.hasNext()){
                listElement = queryResults.next();
                usersList.add(listElement);
            }
        }

        else{
            query = Query.newEntityQueryBuilder()
                    .setKind("User")
                    .build();

            QueryResults<Entity> queryResults = datastore.run(query);

            //TODO: lista todos os atributos
            while(queryResults.hasNext()){
                listElement = queryResults.next();
                usersList.add(listElement);
            }
        }

        return Response.ok(g.toJson(usersList)).build();
    }


    @POST
    @Path("/deleteUser")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deleteUser(DeleteData data) {
        Key userToDeleteKey = datastore.newKeyFactory().setKind("User").newKey(data.usernameToDelete);
        Entity userToDelete = datastore.get(userToDeleteKey);

        if (userToDelete == null) {
            return Response.status(Response.Status.CONFLICT).entity("User to delete does not exist.").build();
        }

        if (!data.verifier.equals("secret")) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong verifier.").build();
        }

        if (data.validTo < System.currentTimeMillis()) {
            return Response.status(Response.Status.FORBIDDEN).entity("Token expired.").build();
        }

        if(data.role.equals("USER")) {
            if(!data.user.equals(data.usernameToDelete)) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }

        } else if(data.role.equals("GBO")) {
            if(!userToDelete.getString("user_role").equals("USER")) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }

        } else if(data.role.equals("GS")) {
            if(!userToDelete.getString("user_role").equals("USER") && !userToDelete.getString("user_role").equals("GBO") ) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }

        } else{
            if(data.user.equals(data.usernameToDelete)) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }
        }

        //delete
        Transaction txn = datastore.newTransaction();

        try{
            txn.delete(userToDeleteKey);
            txn.commit();

            return Response.ok("User created successfully").build();
        }
        finally {
            if(txn.isActive()){
                txn.rollback();
            }
        }
    }



    @POST
    @Path("/modifyUserAtributes")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response modifyUserAttributes(ModifyData data) {
        Key userToModifyKey = datastore.newKeyFactory().setKind("User").newKey(data.userToModify);
        Entity userToModify = datastore.get(userToModifyKey);

        if (userToModify == null) {
            return Response.status(Response.Status.CONFLICT).entity("User to modify does not exist.").build();
        }

        if (!data.verifier.equals("secret")) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong verifier.").build();
        }

        if (data.validTo < System.currentTimeMillis()) {
            return Response.status(Response.Status.FORBIDDEN).entity("Token expired.").build();
        }


        if(data.role.equals("USER")) {
            if(!data.user.equals(data.userToModify)) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }
            if(!userToModify.getString("user_email").equals(data.email) ||
                    !userToModify.getString("user_name").equals(data.name)) {
                return Response.status(Response.Status.FORBIDDEN).entity("You cannot change these attributes.").build();
            }

        } else if(data.role.equals("GBO")) {
            if(!userToModify.getString("user_role").equals("USER")) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }

        } else if(data.role.equals("GS")) {
            if(!userToModify.getString("user_role").equals("USER") && !userToModify.getString("user_role").equals("GBO") ) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }

        } else{
            if(userToModify.getString("user_role").equals("SU")) {
                return Response.status(Response.Status.FORBIDDEN).entity("You do not have permissions").build();
            }
        }

        //modify
        Transaction txn = datastore.newTransaction();

        try{
            userToModify = Entity.newBuilder(userToModifyKey)
                    .set("user_name", data.name)
                    .set("user_pwd", DigestUtils.sha512Hex(data.password))
                    .set("user_email", data.email)
                    .set("user_profile", data.profile)
                    .set("user_phone", data.phone)
                    .set("user_cellPhone", data.cellPhone)
                    .set("user_address", data.address)
                    .set("user_addressC", data.addressC)
                    .set("user_cp", data.cp)
                    .set("user_nif", data.nif)
                    .set("user_creation_time", "user_creation_time")
                    .set("user_role", data.role)
                    .set("user_state", data.state)
                    .build();

            txn.put(userToModify);
            txn.commit();

            return Response.ok("User modified successfully").build();
        }
        finally {
            if(txn.isActive()){
                txn.rollback();
            }
        }
    }



    @POST
    @Path("/changePassword")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response changePassword(ChangePassData data) {
        Key userKey = datastore.newKeyFactory().setKind("User").newKey(data.username);
        Entity user = datastore.get(userKey);

        if (user == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("User doesn't exist.").build();
        }

        if (!data.verifier.equals("secret")) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong verifier.").build();
        }

        if (data.validTo < System.currentTimeMillis()) {
            return Response.status(Response.Status.FORBIDDEN).entity("Token expired.").build();
        }

        if (!user.getString("user_pwd").equals(DigestUtils.sha512Hex(data.oldPassword))) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong password.").build();
        }

        if(!data.newPassword.equals(data.confirmPassword)) {
            return Response.status(Response.Status.FORBIDDEN).entity("New passwords don't match.").build();
        }


        Transaction txn = datastore.newTransaction();

        try{
            user = Entity.newBuilder(userKey)
                    .set("user_pwd", DigestUtils.sha512Hex(data.newPassword))
                    .build();

            txn.update(user);
            txn.commit();

            return Response.ok("Password changed successfully").build();
        }
        finally {
            if(txn.isActive()){
                txn.rollback();
            }
        }
    }



    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response login(LoginData data) {
        Key userKey = datastore.newKeyFactory().setKind("User").newKey(data.username);
        Entity user = datastore.get(userKey);

        if (user == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("User doesn't exist.").build();
        }

        if (!user.getString("user_pwd").equals(DigestUtils.sha512Hex(data.password))) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong user or password.").build();
        }

        Token token = new Token(data.username, user.getString("user_role"));

        return Response.ok(g.toJson(token)).build();
    }



    @POST
    @Path("/registerProperty")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registerProperty(PropertyData data){

        Key userKey = datastore.newKeyFactory().setKind("User").newKey(data.username);
        Entity user = datastore.get(userKey);

        if (user == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("User doesn't exist.").build();
        }

        if (!data.verifier.equals("secret")) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong verifier.").build();
        }

        if (data.validTo < System.currentTimeMillis()) {
            return Response.status(Response.Status.FORBIDDEN).entity("Token expired.").build();
        }

        Transaction txn = datastore.newTransaction();

        try{
            Key propertyKey = datastore.newKeyFactory().setKind("Property").newKey(UUID.randomUUID().toString());
            Entity property = datastore.get(propertyKey);

            if(property != null){
                txn.rollback();
                return Response.status(Response.Status.CONFLICT).entity("Property already exists.").build();
            }
            else{
                property = Entity.newBuilder(propertyKey)
                        .set("property_type", data.propertyType)
                        .set("property_ownerName", data.ownerName)
                        .set("property_ownerNacionality", data.ownerNacionality)
                        .set("property_idDocType", data.idDocType)
                        .set("property_idNum", data.idNum)
                        .set("property_idExpiration", data.idExpiration)
                        .set("property_nif", data.nif)
                        .set("property_parcelVerified", data.parcelVerified)
                        .set("property_uprightLat", data.uprightLat)
                        .set("property_uprightLong", data.uprightLong)
                        .set("property_downleftLat", data.downleftLat)
                        .set("property_downleftLong", data.downleftLong)
                        .build();
            }

            txn.add(property);
            txn.commit();

            return Response.ok("Property registered successfully").build();
        }
        finally {
            if(txn.isActive()){
                txn.rollback();
            }
        }
    }

    @POST
    @Path("/searchProperty")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response searchProperty(ListPropertiesData data) {

        Key userKey = datastore.newKeyFactory().setKind("User").newKey(data.username);
        Entity user = datastore.get(userKey);

        if (user == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("User doesn't exist.").build();
        }

        if (!data.verifier.equals("secret")) {
            return Response.status(Response.Status.FORBIDDEN).entity("Wrong verifier.").build();
        }

        if (data.validTo < System.currentTimeMillis()) {
            return Response.status(Response.Status.FORBIDDEN).entity("Token expired.").build();
        }


        Entity listElement;
        List<Entity> propertiesList = new LinkedList<>();

        //if pra longitude e if pra latitude? como é q distingo?
        Query<Entity> query = Query.newEntityQueryBuilder()
                .setKind("Property")
                .build();

        QueryResults<Entity> queryResults = datastore.run(query);

        while (queryResults.hasNext()) {
            listElement = queryResults.next();
            propertiesList.add(listElement);
        }

        return Response.ok(g.toJson(propertiesList)).build();
    }

}
